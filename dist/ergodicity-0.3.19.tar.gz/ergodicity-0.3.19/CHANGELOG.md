# Changelog

## [0.3.14] - 2024-09-20
### Added
- Read `requirements.txt` automatically in `setup.py`.

## [0.3.11] - 2024-09-19
### Added
- Initial release of the ergodicity library.
